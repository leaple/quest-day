QUEST DAY character idle sprites: 24 characters x 3 stages x 6 frames.
Upload this ZIP to the ROOT of the leaple/quest-day main branch in GitHub; the import workflow extracts and commits each PNG automatically.
